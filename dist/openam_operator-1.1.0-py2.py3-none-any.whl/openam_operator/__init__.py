# Copyright (c) The University of Tokyo and
# National Institute for Materials Science (NIMS). All rights reserved.
# This document may not be reproduced or transmitted in any form,
# in whole or in part, without the express written permission of
# the copyright owners.
__author__ = "Yusuke Manaka"
__version__ = "1.1.0"
__date__ = "20201008"
